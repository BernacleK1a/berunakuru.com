#!/usr/bin/env python
# coding: utf-8

# In[7]:


myDict = {'name':'Edy','age':'26'}
myDict['address'] = 'London'
print(myDict)


# In[8]:


myDict['age']=27
print(myDict)


# In[13]:


def traversDict(dict):
    for key in dict:
        print(key,dict[key])
traversDict(myDict)


# In[16]:


def searchDict(dict, value):
    for key in dict:
        if dict[key] == value:
            return key,value
    return 'The value does not exist'
print(searchDict(myDict, 27))


# In[17]:


myDict.pop('name')


# In[18]:


print(myDict)


# In[19]:


myDict = {'eooooa':1, 'aas':2, 'udd':3, 'sseo':4, 'werwi':5}
print(sorted(myDict, key=len))


# In[20]:


print(myDict)


# In[21]:


myDict.clear()


# In[22]:


print(myDict)


# In[23]:


myDict = {'name':'Edy','age':26}


# In[25]:


print(myDict)


# In[26]:


dict = myDict.copy()


# In[27]:


print(myDict)


# In[29]:


newDict = {}.fromkeys([1,2,3],0 )
print(newDict)


# In[30]:


print(myDict.get('name', 26))


# In[31]:


print(myDict.get('city', 27))


# In[32]:


print(myDict.get('city'))


# In[33]:


print(myDict.items())


# In[34]:


print(myDict.keys())


# In[35]:


print(myDict.values())


# In[36]:


print(myDict.popitem())


# In[37]:


print(myDict)


# In[38]:


print(myDict.setdefault('name', 'added'))


# In[39]:


print(myDict)


# In[41]:


print(myDict.setdefault('name', 'added'))


# In[42]:


print(myDict)


# In[ ]:


newDict = {'a':1, 'b':2, 'c':3}

